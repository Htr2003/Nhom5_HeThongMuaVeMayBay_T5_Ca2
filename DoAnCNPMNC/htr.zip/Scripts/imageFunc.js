﻿var currentImageIndex = 0;
var images = document.querySelectorAll(".banner-image");

function changeImage() {
    images[currentImageIndex].classList.remove("active");
    currentImageIndex = (currentImageIndex + 1) % images.length;
    images[currentImageIndex].classList.add("active");
}

setInterval(changeImage, 5000); // Đổi ảnh sau mỗi 5 giây (5000ms)