﻿using DoAnCNPMNC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DoAnCNPMNC.Controllers
{
    public class UsersController : Controller
    {
        private DBRednitEntities db = new DBRednitEntities();
        // GET: Users
        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public ActionResult DanhSachNguoiDung()
        {
            var Kh = db.KhachHang.OrderByDescending(x => x.KhID).ToList();
            
            return View(Kh);
        }
    }
}